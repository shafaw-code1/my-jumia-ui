function f(x) {
  return 2 * x * x - 5;
}
console.log(f(2)); // 3